# Invented immutable-link policy fixture
Selected governing policy: https://github.com/tvproductions/gz-starter/blob/f42e6f186f062493c09fc2c2dc935e9a64310e33/docs/engineering/architectural-decisions.md
The controller retrieved its exact immutable content through authenticated gh API
for this evaluation. Read source-response.md as that retrieved response, whose
SHA-256 is recorded in source-retrieval.json. It is a transport cache, not an
adapted or independently selected local policy. Use the identified source.
Actual decisions are in docs/decisions. Backplane is disabled. Work locally;
no installs, commits, push or publication. No real operational data is present.
