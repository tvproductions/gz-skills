# Metric measurement fixture
