# Release 0.5.0

Under ADR-0042 edition 999 (approved edition 998), retain one local SQLite file
as the authoritative metrics store, with no independently authoritative second store.

1. Implement the local SQLite metrics storage.
2. Verify that the implementation preserves the single SQLite authority and its constraints.
