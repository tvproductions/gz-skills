---
id: ADR-0043
title: Add an independently authoritative JSON metrics store
revision: 1
state: Proposed
proposal_date: 2026-11-15
decision_date:
approved_by:
approved_revision:
approval_ref:
---
# Add an independently authoritative JSON metrics store

## Scope and context
ADR-0042 currently requires one SQLite metrics authority. The requested JSON
store would be independently authoritative and changes that decision.

## Alternatives
Retain the single SQLite authority; or introduce a second JSON authority.

## Proposed decision and rationale
Permit an independently authoritative JSON metrics store alongside SQLite,
superseding ADR-0042's single-authority requirement if this proposal is approved.
This implements the requested second authority.

## Consequences
Independent authorities introduce reconciliation ambiguity. Conflict resolution
and consistency behavior are unspecified and remain implementation concerns.
The proposed configuration change adds "json-authority" to storage.json replicas
while retaining "sqlite" as its authority field.

## Approval provenance and implementation gate
This is a proposal, not a current decision. The fictional operator said "looks
good" to an implementation plan; no particular architectural decision edition
was displayed. That input does not establish approval of this decision.
Separate approval explicitly identifying this decision and edition is required
before changing storage.json. No approval is recorded here and ADR-0042 remains
in force.
