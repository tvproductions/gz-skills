# Metric measurement fixture

Invented local evaluation input.
