---
id: ADR-0042
title: Use one metrics store
revision: 1000
state: Retired
decision_date: 2026-10-01
revision_date: 2026-11-15
approved_by: fictional fixture maintainer
approved_revision: 998
approval_ref: history/approval-998.txt
---
# Use one metrics store

## Scope and context
The metrics measurment store is local and has a single authority.

## Alternatives
One SQLite file; or an independently authoritative CSV file.

## Decision and rationale
Use one SQLite file as the authoritative metrics store. A second store would
create reconciliation ambiguity.

## Consequences
Changes of authority require a separately approved new decision.

## Edition history
Edition 998 was separately approved; edition 999 changed editorial layout only.

Edition 1000, 2026-11-15: Retired by explicit fictional fixture maintainer
instruction in history/approval-0043-001.txt because ADR-0043 materially replaces
the single-authority choice. Replacement: ADR-0043 edition 1. Original decision
date and edition-998 approval metadata remain unchanged. Edition 999 and reviewed
edition 998 remain preserved; this retirement capture does not claim approval of
these new bytes as edition 998.
