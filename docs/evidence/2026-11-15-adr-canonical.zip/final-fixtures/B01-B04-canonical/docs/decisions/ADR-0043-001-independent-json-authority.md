---
id: ADR-0043
title: Add an independently authoritative JSON metrics store
revision: 1
state: Current
decision_date: 2026-11-15
revision_date: 2026-11-15
approved_by: fictional fixture maintainer
approved_revision: 1
approval_ref: history/approval-0043-001.txt
---
# Add an independently authoritative JSON metrics store — proposal, edition 1

## Scope and context

This is an unapproved proposal in an invented fixture. Current ADR-0042 edition
999 preserves the single SQLite authority approved at edition 998, with evidence
in ../decisions/history/approval-998.txt and its referenced reviewed content.
storage.json currently has authority sqlite and an empty replicas array.
The requested change adds json-authority to replicas as a second independent
authority. Its placement in replicas does not remove the authority conflict.

## Alternatives

- Retain SQLite as the sole authority: preserves the approved constraint and
  avoids cross-store reconciliation, but does not satisfy the requested change.
- Add a derived, nonauthoritative JSON replica: permits JSON consumption while
  preserving one authority, but does not provide independent authority.
- Add independent JSON authority: satisfies the request but introduces the
  reconciliation ambiguity identified by ADR-0042.

## Decision and rationale

Propose adding json-authority to storage.json replicas while retaining sqlite
as the existing authority. This materially replaces ADR-0042's single-authority
choice and requires separate explicit approval of ADR-0043 edition 1.
The request supplies intent, but no evidence that two authorities are necessary
or how conflicts, writes, recovery, or precedence will work. Approval must
explicitly accept this fixture-only configuration scope and unresolved ambiguity,
or review a later edition supplying those rules before dependent implementation.

## Consequences

The configuration would express two independent authorities. No synchronization
or conflict-resolution behavior is established by this proposal. No deployment,
migration, or real operational action is authorized. ADR-0042 remains unchanged;
its retirement requires explicit authority as well as approval of the new choice.

## Confirmation

After applicable approval and retirement authority are evidenced, verify that
storage.json retains authority sqlite and contains json-authority in replicas.
Check alignment with the approved decision in addition to JSON validity.

## Approval evidence

None for this edition. The supplied fictional operator response, "looks good",
approved an implementation plan; no identified ADR edition was displayed.
It is not architectural approval. Preserve these proposed bytes and the actual
edition-specific response before any administrative acceptance edits.

## Amendment history

- 2026-11-15: Created proposed edition 1; no architectural approval claimed.

## Administrative acceptance capture — 2026-11-15

The fictional fixture maintainer explicitly approved edition 1 and its documented
uncertainty in the staged user response preserved verbatim in
history/approval-0043-001.txt. The exact reviewed bytes are preserved in
history/ADR-0043-001-reviewed.txt, SHA-256
4ac0efb31c7f47b72c064032f870012b1d1f5c1f558866be31b8a99d98cda3ea.
The proposal above retains its review-time wording. Filling frontmatter approval
and state fields and appending this capture are subsequent administrative edits;
these edited bytes were not the reviewed proposal. Approval applies only to this
invented exercise. The same response separately authorizes ADR-0042 retirement
and the local configuration change. ADR-0042 edition 1000 records that retirement.
