---
id: ADR-0042
title: Use one metrics store
revision: 1000
state: Current
decision_date: 2026-10-01
revision_date: 2026-11-15
approved_by: fictional fixture maintainer
approved_revision: 998
approval_ref: history/approval-998.txt
---
# Use one metrics store

## Scope and context
The metrics measurement store is local and has a single authority.

## Alternatives
One SQLite file; or an independently authoritative CSV file.

## Decision and rationale
Use one SQLite file as the authoritative metrics store. A second store would
create reconciliation ambiguity.

## Consequences
Changes of authority require a separately approved new decision.

## Edition history
Edition 998 was separately approved; edition 999 changed editorial layout only.

Edition 1000 (2026-11-15): corrected spelling from `measurment` to
`measurement` in scope and context; editorial only, with no change to the
approved architectural choice. Approval remains for edition 998; no approval
of this editorial edition is claimed. Preserved prior edition:
[edition 999](history/ADR-0042-999-one-metrics-store.md).
