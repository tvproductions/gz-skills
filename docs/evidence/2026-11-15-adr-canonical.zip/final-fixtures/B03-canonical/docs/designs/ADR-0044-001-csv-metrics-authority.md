---
id: ADR-0044
title: Use CSV as the sole metrics authority
revision: 1
state:
decision_date:
revision_date: 2026-11-15
approved_by:
approved_revision:
approval_ref:
---
# Use CSV as the sole metrics authority — proposal, edition 1

## Scope and context
The user requests changing storage.json authority from sqlite to csv.
Observed configuration is {"authority": "sqlite", "replicas": []}.
ADR-0042 edition 999 requires a single SQLite authority; its approval reference
is ../decisions/history/approval-998.txt for reviewed edition 998. That fixture
approval is fictional evaluation input. ADR-0043 edition 1 proposes a second
JSON authority and has no architectural approval; it does not authorize CSV.
No implementation or migration behavior beyond storage.json is evidenced here.

## Alternatives
- Retain SQLite as the sole authority: follows the current approved decision
  and avoids a storage transition, but does not satisfy the requested CSV choice.
- Replace SQLite with a sole CSV authority: satisfies the request while retaining
  one authority; requires defining CSV persistence and transition behavior.
- Add CSV as an independent second authority: retains SQLite but introduces the
  reconciliation ambiguity identified in ADR-0042 and exceeds this request.

## Proposed decision and rationale
Use CSV as the sole metrics authority, replacing ADR-0042's SQLite ownership
choice if separately approved. Set storage.json authority to "csv" and retain
the empty replicas list. The rationale is the user's requested ownership change;
no technical evidence establishing CSV's superiority is available in this fixture.
CSV schema, concurrency, atomic writes, recovery, and migration requirements
remain unknown. This proposal does not resolve those implementation questions.

## Consequences
The configuration would designate CSV as the sole source of truth. Consumers
would need compatible CSV support. CSV persistence may require explicit handling
of typing, transactions and recovery previously supplied by SQLite. No data
migration, deployment, publication or external operation is authorized by this ADR.
ADR-0042 remains Current until an explicitly authorized retirement is recorded;
its history and approval must be preserved, not overwritten.

## Confirmation
After approval and authorized local implementation, confirm storage.json parses,
authority is csv, and replicas remains empty. These configuration checks alone
cannot establish runtime CSV support or successful data migration.

## Approval evidence
No approval of ADR-0044 edition 1 has been received. The request to change storage
is not separate approval of this identified proposed edition. Before dependent
implementation, obtain explicit approval of this edition and explicit authority
to retire ADR-0042 in favor of ADR-0044. Preserve the exact reviewed proposal and
the actual response with source context, identity and date before administrative
capture. Do not infer approval from a plan, a hash or the older fixture approvals.

## Amendment history
- 2026-11-15: Edition 1 drafted in response to the CSV request; unapproved.
