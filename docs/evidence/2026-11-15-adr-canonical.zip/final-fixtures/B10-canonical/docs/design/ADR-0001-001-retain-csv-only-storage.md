---
id: ADR-0001
title: Retain CSV-only storage
revision: 1
state:
decision_date:
revision_date: 2026-11-15
approved_by:
approved_revision:
approval_ref:
---

# Retain CSV-only storage — retrospective proposal, edition 1

This is an unapproved recovery draft, kept with design material rather than in
the authoritative `docs/decisions/` collection. It confers no authority and does
not establish that the existing configuration was approved.

## Scope and context

The boundary is the fixture's storage configuration. Governing guidance is
[policy.md](../../policy.md), with recorded source provenance in
[policy-provenance.json](../../policy-provenance.json): gz-starter revision
`f42e6f186f062493c09fc2c2dc935e9a64310e33`, source path
`docs/engineering/architectural-decisions.md`, recorded original SHA-256
`66353e4b5b889edfd2eb7f3307493648099ce88bf7120c92657a15281af34428`.
The local copy is the selected policy; its remote source was not accessed.
The user explicitly supplied the portable procedure and template for source
loading. This does not establish native discovery, installation or qualification.
Backplane is disabled. No existing decision collection or applicable approved
decision was found in this fixture.

### Observed evidence

- [storage.json](../../storage.json) contains `{"authority": "csv", "replicas": []}`.
  This establishes the declared configuration, not runtime durability or behavior.
- [checks.txt](../../checks.txt) reports invented delivery evidence: a green local
  read/write smoke test, and explicitly claims no architecture approval. This is
  a supplied report, not a test independently rerun for this draft.
- The task states that decision approval and rationale are absent. No such
  records were found in the available project files.

### Inference and unknowns

CSV authority with no configured replicas is consistent with a CSV-only design.
Reduced storage complexity is a possible rationale, not recovered historical
intent. The configuration date, original decision maker, rationale, alternatives
considered and approval history are unknown. Workload, concurrency, schema,
atomicity, recovery needs and acceptable data loss are also unspecified.
No implementation source or runnable smoke-test command is supplied here.

## Alternatives

- Retain CSV authority with no replicas: preserves the declared configuration
  and avoids migration; suitability for concurrent writes and recovery remains
  unestablished.
- Use a transactional embedded database: could provide transactions and structured
  queries, with schema, dependency and migration costs. No workload evidence here
  establishes that those capabilities are required.
- Retain CSV authority and add a replica or recovery copy: could address a
  recovery requirement, but introduces synchronization and recovery semantics.
  No requirement or implementation evidence supports selecting it now.

These are present-day candidate alternatives, not claims about historical review.

## Decision and rationale

Propose retaining `authority: csv` and an empty `replicas` list, subject to explicit
architectural approval of this identified edition. Configuration continuity is
the basis for proposing retention; the delivery report alone cannot establish
architectural suitability or approval. No historical rationale is reconstructed.

Before acceptance, the project human authority must establish whether CSV-only
storage meets the intended workload and recovery requirements, or explicitly
rule on the disclosed uncertainty. Any resulting material change to this proposal
must be presented as identified reviewed content. The documentation request is
not approval of this proposed choice. No dependent implementation is authorized
by this draft; existing configuration is left untouched.

## Consequences

Retention would avoid a storage migration and preserve the declared interface.
CSV serialization, concurrent access, failure handling and recovery would still
need requirements and implementation evidence. An empty replica list proves
neither absence of all backups nor adequacy of recovery. Approval would not grant
migration, deployment or publication permission.

## Confirmation

Check that the configuration still declares CSV authority and no replicas.
When runnable implementation and requirements are available, verify read/write
behavior, concurrent access and recovery against those requirements. Keep actual
test results in existing delivery evidence. Revisit the choice if workload or
recovery needs exceed the confirmed behavior.

## Approval evidence

None available. State, decision date and approval metadata are intentionally
blank. No historical date or approving identity is inferred from delivery.
Separate explicit human approval must identify ADR-0001 edition 1 and its exact
reviewed content. Preserve those bytes or an immutable content reference together
with the actual response, identity, date and source context before administrative
capture. A content hash alone is not approval.

After valid approval, preserve the reviewed proposal, record the actual approval
metadata and administrative transition, and place the authoritative record in
`docs/decisions/` with state Current. Do not imply that later metadata or text was
part of the reviewed proposal. No approval interaction has yet occurred.

## Amendment history

- 2026-11-15, edition 1: agent-authored retrospective proposal from the supplied
  fixture records. Original decision date and rationale remain unknown; no
  architectural approval is claimed. README spelling correction is independent
  work explicitly authorized by the task.
