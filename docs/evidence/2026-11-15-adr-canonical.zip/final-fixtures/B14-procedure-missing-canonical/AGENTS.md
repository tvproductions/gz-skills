# Invented unavailable-workflow fixture
Selected policy: policy.md with policy-provenance.json. Selected portable ADR
procedure: unavailable-workflow/SKILL.md. It is unavailable; do not install or
silently substitute another workflow. This is a project-selected availability
case. Do not claim the procedure is loaded from its configured path. Current
local work is limited to this fixture; no network, Git mutation or external work.
