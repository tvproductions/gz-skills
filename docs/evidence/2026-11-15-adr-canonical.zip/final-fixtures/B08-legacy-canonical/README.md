# Metric measurement fixture

Current decision: [DECISION-A edition 8](decisions/decision-a.ed8.md).
