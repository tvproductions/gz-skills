# Invented legacy-convention fixture
Selected policy: policy.md with policy-provenance.json. Use the exact canonical
ADR procedure/template explicitly provided by the evaluator. Existing collection:
decisions/. Preserve its suitable established convention; do not migrate it.
Semantic mapping: key=id, edition=revision, status accepted=Current,
approved_edition=approved_revision, approved_on=decision_date,
edited_on=revision_date, approval=approval_ref. Fictional approver is identified
in approval.txt; exact reviewed edition-6 content is in reviewed-ed6.txt.
Filename convention: decision-a.ed<edition>.md. Prior editions live in history/.
Work locally in this fixture; no network, install, Git mutation or external work.
