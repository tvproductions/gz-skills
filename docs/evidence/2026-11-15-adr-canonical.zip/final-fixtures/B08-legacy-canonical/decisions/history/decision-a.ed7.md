---
key: DECISION-A
edition: 7
status: accepted
approved_edition: 6
approved_on: 2026-10-01
edited_on: 2026-11-01
approval: history/approval.txt
---
# One metrics authority
Use one SQLite metrics authority. Correcting the measurment spelling does not change this choice.
