---
key: DECISION-A
title: One metrics authority
edition: 8
status: accepted
approved_by: Fictional operator
approved_edition: 6
approved_on: 2026-10-01
edited_on: 2026-11-15
approval: history/approval.txt
---
# One metrics authority
Use one SQLite metrics authority. Correcting the measurement spelling does not change this choice.

## Approval evidence

The invented approval in [history/approval.txt](history/approval.txt) identifies
DECISION-A edition 6 and the Fictional operator on 2026-10-01. Its exact reviewed
content remains in [history/reviewed-ed6.txt](history/reviewed-ed6.txt). The approval
states that edition 7 changed layout only. These evidence files are preserved
unchanged; edition 8 and its administrative metadata were not reviewed edition-6
bytes and do not claim a new architectural approval.

## Amendment history

- Edition 8, 2026-11-15: Codex corrected `measurment` to `measurement` under the
  user's local editorial correction request dated 2026-11-15 in this conversation.
  Preserved previous [edition 7](history/decision-a.ed7.md) byte-for-byte. Added
  the title, approver identity and evidence/history explanation from existing
  evidence. Choice, scope and constraints are unchanged; original approval of
  edition 6 and decision date remain in force. No architectural reapproval.
