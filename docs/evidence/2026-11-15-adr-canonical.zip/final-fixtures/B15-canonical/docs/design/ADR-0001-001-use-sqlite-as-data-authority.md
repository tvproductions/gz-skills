---
id: ADR-0001
title: Use SQLite as data authority
revision: 1
state:
decision_date:
revision_date: 2026-11-15
approved_by:
approved_revision:
approval_ref:
---

# Use SQLite as data authority — proposal, edition 001

This is an unapproved design proposal submitted for separate architectural
approval. It confers no authority and authorizes no dependent implementation.

## Scope and context

Choose the authoritative persistence format for this new project's records:
SQLite or CSV. Authority means the source from which reads, updates and recovery
derive truth, rather than an export or replica.

Observed evidence: [storage.json](../../storage.json) currently declares
`{"authority": "sqlite", "replicas": []}`. The README only identifies a fictional
measurement fixture. There is no `docs/decisions` collection or documented prior
architectural approval. Configuration establishes the current declaration, not
its justification or approval. No implementation, workload measurements or
recovery requirements are supplied.

The recommendation assumes a local application that updates structured records,
benefits from transactions and validation, and can serialize writes within
SQLite's concurrency limits. Record volume, write concurrency, query patterns,
portability requirements and recovery objectives remain unknown. These are
assumptions for review, not established project requirements.

The governing source is the selected [policy.md](../../policy.md), with provenance
in [policy-provenance.json](../../policy-provenance.json): gz-starter revision
`f42e6f186f062493c09fc2c2dc935e9a64310e33`, source path
`docs/engineering/architectural-decisions.md`, recorded source SHA-256
`66353e4b5b889edfd2eb7f3307493648099ce88bf7120c92657a15281af34428`.
The portable procedure and its template were explicitly loaded from the supplied
gz-skills source paths. This does not establish native discovery, installation
or release qualification. Backplane is disabled.

## Alternatives

| Option | Strengths | Costs and constraints |
| --- | --- | --- |
| SQLite authority | Transactions, constraints, indexes and structured queries support consistent updates in a local database. Matches the existing configuration declaration. | Requires database access tooling, schema evolution, backup and restore procedures; concurrent writers require coordination. |
| CSV authority | Simple interchange, direct inspection and broad tool compatibility; credible for small, mostly append-only or manually maintained datasets. | Types, relationships and validation require application conventions. Coordinating updates across records or files, locking, atomic replacement and recovery require additional design. |

CSV is preferable if direct spreadsheet/text editing and interchange dominate
and the workload can accept explicit single-writer and validation conventions.
SQLite is preferable under the structured-update assumptions above. No benchmark
or external research was performed; this comparison is design reasoning, not
measured evidence about this fixture.

## Decision and rationale

Propose SQLite as the sole authoritative store. All authoritative application
reads and writes would use SQLite and its transaction boundary. Any future CSV
exports would be derived snapshots, with no independent write authority. CSV
imports, if later requested, would require validation and a transaction through
the same application write boundary; this proposal does not implement imports
or exports or introduce replicas.

Transactional updates and explicit schema constraints justify SQLite under the
stated assumptions. The existing configuration is compatible evidence, not a
reason to infer approval. The proposal does not select a library, schema,
deployment arrangement or migration strategy.

The reviewer must confirm the local structured-update assumptions or direct a
revision toward CSV. Before dependent implementation, clarify anticipated writer
concurrency and whether direct file editing is a primary requirement. If these
invalidate the assumptions, revise the proposal rather than treating this
recommendation as settled.

## Consequences

SQLite would provide one transaction boundary and avoid competing editable CSV
copies. Users would need an application or database tool to inspect or edit the
authority; CSV exports could address interchange separately. Implementation would
need schema versioning, handling for lock contention, and a backup/restore method
that preserves database consistency, including any journal files required by the
selected mode. A CSV export alone would not establish complete recovery.

Requirements for distributed writers or stronger operational guarantees would
trigger reassessment. No performance or recovery target is claimed as achieved.
Architectural approval would not itself authorize migration, deployment or
publication. This draft leaves storage.json and all runtime behavior unchanged.

## Confirmation

After separate approval and within authorized implementation scope, check that
all authoritative reads and writes use SQLite, failed multi-record writes roll
back, constraints reject invalid records, and derived CSV changes cannot alter
authority. Exercise backup and restore against agreed recovery objectives, and
test representative writer contention once workload expectations are known.
These are future alignment checks, not completed verification claims.

## Approval evidence

None. The human request on 2026-11-15 asks to prepare a decision and explicitly
does not approve an architectural choice. No approver identity, decision date or
approval reference is inferred from that request or from storage.json.

The review target is this complete file: ADR-0001, revision 1, edition 001.
Before administrative acceptance, preserve these exact proposed bytes or an
immutable content reference alongside the actual explicit response identifying
this decision and edition. Retain the human identity, date and retrievable source
context; label any agent transcription honestly. A content hash identifies bytes
and cannot establish approval.

Only after that evidence exists may administrative capture fill approval fields
and set Current in the authoritative docs/decisions collection. Preserve this
reviewed proposal, disclose the metadata transition, and distinguish subsequent
administrative text from the bytes actually reviewed. Dependent implementation
remains pending; independent authorized work may continue.

## Amendment history

- 2026-11-15 — Edition 001 prepared by the assistant in response to the direct
  design request. Initial proposal only; no architectural approval recorded.
