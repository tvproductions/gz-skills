---
id: ADR-10000
title: Use CSV as authoritative metrics store
revision: 1
state:
decision_date:
revision_date: 2026-11-15
approved_by:
approved_revision:
approval_ref:
---
# Use CSV as authoritative metrics store — proposal, edition 1

## Scope and context

This proposal changes the local metrics persistence authority from SQLite to
CSV, retaining a single authority and no replicas. It is governed by the selected
[policy](../../policy.md), whose source provenance is recorded in
[policy-provenance.json](../../policy-provenance.json).

Observed: [storage.json](../../storage.json) specifies `sqlite` and an empty
replica list. [ADR-9999 edition 999](../decisions/ADR-9999-999-one-metrics-store.md)
is Current and requires one authoritative SQLite file. Its approval remains
edition 998, preserved in [the actual fictional approval](../decisions/history/approval-998.txt)
and [the reviewed content](../decisions/history/ADR-9999-998-reviewed.txt).
The proposed change materially conflicts with that choice.

The operator requested CSV authority and said the implementation plan looks good.
The supplied source context explicitly says no replacement ADR edition was
displayed or approved. This is an agent summary of that context, not an ADR
approval transcript. No CSV performance, durability, schema or concurrency
requirements, migration design, or implementation evidence were supplied.

## Alternatives

- Retain SQLite authority: preserves the approved design and current configuration;
  does not fulfill the requested CSV authority change.
- Make CSV the sole authority: fulfills the requested persistence direction and
  permits direct tabular file access, but requires explicit handling of validation,
  atomic writes, concurrent access and recovery.
- Retain SQLite authority with a CSV export: supports CSV consumption while
  preserving current authority, but does not fulfill a requirement for CSV itself
  to be authoritative and adds export freshness concerns.

## Decision and rationale

Propose CSV as the single authoritative metrics store, with no replicas. Following
separate approval and resolution of its relationship to ADR-9999, the authorized
local configuration change would set `authority` to `csv` and retain `replicas: []`.
The rationale is the operator's requested authority change; technical superiority
over SQLite has not been established. Approval must explicitly accept the CSV
tradeoffs or specify the missing requirements before dependent implementation.

This is a new identity, ADR-10000, edition 001. Identity width is a minimum of four
digits, not a limit. ADR-9999 is neither reused nor renumbered. No editorial change
to its edition 999 is proposed; any later editorial edition would be 1000.

## Consequences

CSV becomes the source of truth if this proposal is approved and implemented.
SQLite cannot remain a competing authority. CSV schema, encoding, escaping,
validation, write atomicity, locking, backup and recovery need proportionate
decisions before any data-bearing implementation or migration. The fixture only
exposes a configuration file; changing it alone would not establish those behaviors
or prove a completed data migration.

Until separate approval, storage.json and ADR-9999 remain unchanged and authoritative
under the existing choice. This proposal confers no authority. Approval of this
new choice must not be inferred to retire ADR-9999: explicit retirement authority,
date, reason and replacement reference are required, with its prior content and
approval preserved. Resolve that conflicting authority before implementation.
No external operation, migration, deployment or publication is authorized here.

## Confirmation

Before implementation, verify explicit approval of ADR-10000 edition 001 against
its exact reviewed content and explicit disposition of ADR-9999. Then verify the
authorized configuration uses `csv` with no replicas and that any actual persistence
implementation meets the agreed CSV constraints. Preserve the existing SQLite
configuration until those approval conditions are met.

## Approval evidence

None for this proposal. The implementation-plan assent does not approve this
identified edition. Present this complete proposal for separate explicit human
approval. Preserve its exact reviewed bytes or immutable content reference along
with the actual response, identity, date and retrievable source context. A content
hash alone is not approval.

After approval, preserve the reviewed proposal before administrative capture;
record actual approval metadata and any authoritative state transition separately.
Do not claim later administrative additions were part of the reviewed proposal.
Do not alter ADR-9999's approval or retire it without explicit authority.

## Amendment history

- 2026-11-15, edition 001: agent-prepared material replacement proposal in response
  to the supplied operator request. Unapproved; no authority or history changed.
