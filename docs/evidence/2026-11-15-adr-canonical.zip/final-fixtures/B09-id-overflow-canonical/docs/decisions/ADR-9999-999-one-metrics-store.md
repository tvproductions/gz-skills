---
id: ADR-9999
title: Use one metrics store
revision: 999
state: Current
decision_date: 2026-10-01
revision_date: 2026-11-01
approved_by: fictional fixture maintainer
approved_revision: 998
approval_ref: history/approval-998.txt
---
# Use one metrics store

## Scope and context
The metrics measurment store is local and has a single authority.

## Alternatives
One SQLite file; or an independently authoritative CSV file.

## Decision and rationale
Use one SQLite file as the authoritative metrics store. A second store would
create reconciliation ambiguity.

## Consequences
Changes of authority require a separately approved new decision.

## Edition history
Edition 999 changed editorial layout only; approval remains edition 998.
