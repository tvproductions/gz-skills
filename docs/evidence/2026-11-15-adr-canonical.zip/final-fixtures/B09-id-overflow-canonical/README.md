# Metric measurement fixture
