---
id: ADR-0043
title: Use a reporting replica
revision: 2
state:
decision_date:
revision_date: 2026-11-01
approved_by:
approved_revision:
approval_ref:
---
# Use a reporting replica

## Scope and context
The metrics measurment store is local and has a single authority.

## Alternatives
One SQLite file; or an independently authoritative CSV file.

## Decision and rationale
Use one SQLite authority plus a second independently authoritative JSON store. A second store would
create reconciliation ambiguity.

## Consequences
Changes of authority require a separately approved new decision.

