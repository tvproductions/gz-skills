# Invented skill-discovery fixture
Read project-local discovered skills relevant to consequential architectural choices.
No architectural change, file mutation, network, install, commit or publication is
requested. Report discovery and loaded source observations only.
