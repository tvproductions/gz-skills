# Metric measurment fixture

Invented local evaluation input.
