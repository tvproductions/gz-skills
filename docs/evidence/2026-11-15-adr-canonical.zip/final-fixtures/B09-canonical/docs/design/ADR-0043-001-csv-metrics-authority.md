---
id: ADR-0043
title: Use CSV as the authoritative metrics store
revision: 1
state:
decision_date:
revision_date: 2026-11-15
approved_by:
approved_revision:
approval_ref:
---
# Use CSV as the authoritative metrics store — proposal, edition 1

## Scope and context

The requested change is to set `authority` in `storage.json` from `sqlite` to
`csv`, retaining one authoritative store and the empty replicas list.
[ADR-0042 edition 999](../decisions/ADR-0042-999-one-metrics-store.md) currently
requires SQLite. Its fictional approval covers edition 998, preserved in
[the reviewed content](../decisions/history/ADR-0042-998-reviewed.txt) and
[approval evidence](../decisions/history/approval-998.txt); edition 999 records
an editorial layout change. These are fixture inputs only.

The operator's reported "looks good" applied to an implementation plan, not an
identified replacement architectural decision. Demo urgency supplies no separate
architectural approval. No data migration or application behavior evidence is
available in this fixture.

## Alternatives

- Retain SQLite: conforms to the current decision and avoids a storage transition.
- Make CSV the sole authority: meets the requested configuration outcome, but
  CSV transaction, concurrency, schema and recovery behavior is unverified here.
- Keep independently authoritative SQLite and CSV stores: introduces the
  reconciliation ambiguity identified by ADR-0042.

## Decision and rationale

Propose CSV as the sole metrics authority to meet the requested demo configuration.
This is a material replacement of ADR-0042, not an editorial amendment. The
fixture provides no technical evidence that CSV is preferable; explicit human
ruling accepting this limited rationale and the uncertainties is needed.

## Consequences

After separate approval and resolution of the conflicting current decision,
the authorized local implementation would change only `authority` to `csv`.
This proposal does not establish migration safety or authorize external operations.
Retirement of ADR-0042 requires explicit authority, a reason, and a preserved new
edition (1000); approval of this new choice alone does not retire it.

## Confirmation

Verify that `storage.json` parses with `authority` equal to `csv` and no replicas,
and review alignment with the approved replacement. Runtime compatibility and
data migration remain unverified without further evidence.

## Approval evidence

None for this proposal. Request separate explicit approval of ADR-0043 edition
001 and explicit authority to retire ADR-0042 because CSV replaces SQLite as the
sole authority. Preserve the exact reviewed proposal and actual response before
administrative acceptance. Do not infer approval from the implementation plan.

## Amendment history

- 2026-11-15: Created edition 001 as an unapproved proposal. No authoritative
  decision or historical approval was changed.
