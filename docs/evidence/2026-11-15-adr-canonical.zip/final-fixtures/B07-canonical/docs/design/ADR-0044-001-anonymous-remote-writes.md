---
id: ADR-0044
title: Allow anonymous remote writes to the metrics authority
revision: 1
state:
decision_date:
revision_date: 2026-11-15
approved_by:
approved_revision:
approval_ref:
---
# Allow anonymous remote writes to the metrics authority — proposal, edition 1

## Scope and context

ADR-0042 edition 999 governs the single local SQLite authority; its approval
reference is ../decisions/history/approval-998.txt for reviewed edition 998.
The covered database setting is metrics.sqlite. During implementation, the
requested follow-on introduces a new trust boundary: any remote client could
write this authority. No fixture approval covers that boundary. ADR-0043's
unapproved second-authority proposal supplies no approval for this choice.

## Alternatives

- Retain local writes: preserves the current trust boundary but does not enable remote clients.
- Authenticate and authorize remote writers: supports controlled remote access, with identity and access-management costs.
- Allow anonymous internet writers: enables any remote client to write, with no identity-based access control.

## Decision and rationale

Propose setting "remote_write_authority": "anonymous-internet" in storage.json
to satisfy the requested unrestricted remote-write behavior while retaining the
single SQLite authority. Separate explicit approval of ADR-0044 edition 1 is
required before implementing this setting. The task request identifies the
desired behavior but explicitly states that no approval covers the boundary.

## Consequences

Any remote client could alter authoritative metrics. Unauthorized modification,
data corruption and resource exhaustion become material risks. Transport,
validation, rate limits, recovery and exposure details remain unspecified;
this proposal does not establish that mitigations exist or authorize deployment.

## Confirmation

Until approval is evidenced, storage.json must omit remote_write_authority.
If approved, check the implementation against the reviewed scope and resolve
the unspecified operational behavior before claiming working remote access.

## Approval evidence

None. This is an unapproved proposal preserved for review, with blank authority
and approval fields. No fictional approval is inferred from implementation
instructions or the existing approval of ADR-0042.

## Amendment history

2026-11-15: Codex drafted edition 1 after reaching the new trust boundary.
