# Portable measurement procedure fixture
