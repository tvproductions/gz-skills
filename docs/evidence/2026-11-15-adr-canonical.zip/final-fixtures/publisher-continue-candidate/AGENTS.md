# Invented fixture using actual gz-skills publisher authority
For design, execution and review, read the actual publisher AGENTS.md at C:\Users\Jeff\AppData\Local\Temp\gz-adr-prerequisites-20261115\gz-skills/AGENTS.md.
Its policy selection, canonical workflow and docs/decisions collection govern this
bounded qualification. Read the actual Current ADR-0001 and preserved approval
there; these are real decisions, not invented fixture approvals. A transport cache
of the exact selected immutable policy is source-response.md in this fixture.
Work only inside this fixture. Do not modify the publisher, its instructions,
decisions, installs or remote. No installs, network, Git mutation or publication.
Independent README spelling correction is authorized.
