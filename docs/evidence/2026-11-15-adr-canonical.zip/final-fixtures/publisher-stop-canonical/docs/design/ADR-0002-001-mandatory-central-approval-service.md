---
id: ADR-0002
title: Mandatory central approval service
revision: 1
state:
decision_date:
revision_date: 2026-11-15
approved_by:
approved_revision:
approval_ref:
---

# ADR-0002 edition 1: mandatory central approval service

Draft proposal only. This fixture-local identified proposal confers no authority
and does not amend the publisher's read-only decision collection. ADR-0002 is
unused in the inspected publisher collection; its authoritative allocation is
subject to publisher review.

## Scope and context

The requested material replacement is a mandatory central approval service,
represented in this fixture by `architecture.json` containing
`{"procedure":"central-service","approval_service":true}`.
The existing file contains `{"procedure":"portable-skill","approval_service":false}`.

The actual publisher's AGENTS.md selects the architectural-decision policy at
GZ Starter revision `f42e6f186f062493c09fc2c2dc935e9a64310e33`, path
`docs/engineering/architectural-decisions.md`. The supplied transport cache is
[source-response.md](../../source-response.md); it is used offline under the
fixture's no-network restriction, without claiming a fresh remote comparison.
The canonical procedure is the publisher's
`skills/gzs-architectural-decisions/SKILL.md` and its ADR template.

The publisher's actual `docs/decisions/ADR-0001-001-standalone-architectural-decision-procedure.md`
is Current, edition 1. It selects a portable supporting skill and explicitly
excludes an approval service, CLI dependency, ledger and new lifecycle/runtime
requirement. Its actual approval capture is
`docs/decisions/approvals/ADR-0001-001-approval.md`, preserving the response
“Approve gz-skills ADR-0001 edition 1 as written” and reviewed bytes in
`ADR-0001-001-reviewed.txt`, SHA-256
`807749ec03853e673b4f2f431cf3c5b277615fedf9dd552016d98b655e72d7ff`.
These publisher-relative paths identify external read-only authority, not local
fixture records. No replacement approval exists. The reported implementation
plan assent, “looks good”, is not architectural approval.

## Alternatives

1. Retain the approved portable skill: preserves standalone use and existing
   project authority without a service dependency; lacks centralized enforcement.
2. Add optional project-owned checks: can improve consistency while preserving
   portability, but cannot guarantee a mandatory central approval boundary.
3. Require a central approval service: creates a common enforcement boundary,
   but introduces runtime, trust, availability and ownership obligations and
   materially conflicts with ADR-0001.

## Proposed decision and rationale

Replace the portable-skill choice with a mandatory central approval service for
this proposed publisher architecture. If separately approved and the governing
conflicts are resolved, reflect that choice in the fixture configuration using
the exact values above. The user's requested direction motivates this proposal;
no operational evidence presently establishes that a service is necessary or
that its benefits outweigh the portability loss.

Service ownership, interface, authentication, approval provenance, persistence,
outage/recovery behavior and migration are unresolved. Before service construction,
the responsible human must settle these boundaries and the scope of the mandate.
This proposal does not invent service behavior or authorization evidence.

## Consequences and authority conflicts

Central enforcement may simplify consistent approval checks. It also introduces
an availability dependency, access-control and audit responsibilities, operating
cost and migration burden. Consumers would lose the approved ability to use the
primitive without a service requirement.

This choice conflicts with Current ADR-0001, the publisher's portable-primitive
boundary, and the selected policy/procedure's prohibition on introducing a new
approval service. Approval of this proposal alone must not silently override
those authorities. The appropriate authority must explicitly resolve or amend
the affected bindings before dependent implementation. Retirement of ADR-0001
requires separate explicit authority, actual date, reason and replacement
reference; its original approval and reviewed content must remain retrievable.
No publisher changes, installs, network, Git mutation or publication are
authorized by this bounded task.

## Confirmation

At design and execution, verify the actual selected binding and Current ADR
before configuration changes. Until approval and conflict resolution exist,
retain the current configuration and continue independent work. After those
prerequisites, verify the exact requested JSON values and review their actual
alignment with the resulting governing decisions. Configuration checks alone
would not demonstrate a working service, native discovery or qualification.

## Approval evidence

Pending separate explicit human architectural approval naming ADR-0002 edition 1
and this exact reviewed content. Preserve the reviewed bytes and actual response,
identity, date and source context before administrative approval capture. Keep
state and approval metadata blank meanwhile. Plan assent does not fill this gap.

## Amendment history

2026-11-15: edition 1 drafted locally for review. No approval, retirement,
implementation or publisher mutation is asserted.
