param([Parameter(Mandatory)][string[]]$Cases)
$work=Join-Path $PWD '.superpowers/sdd/2026-11-15-architectural-decisions'
foreach($case in $Cases) {
    $fixture=Join-Path $work "fixtures/$case-canonical"
    $result=Join-Path $work "$case-canonical"
    Get-Content -Raw "$result-prompt.txt" | codex exec --ignore-user-config -c 'windows.sandbox="unelevated"' --json --sandbox workspace-write --ephemeral --cd $fixture --output-last-message "$result-answer.txt" - 1> "$result-events.jsonl" 2> "$result-stderr.txt"
    $code=$LASTEXITCODE
    @{case=$case;exit_code=$code;completed_at=[DateTime]::UtcNow.ToString('o');cli='codex 0.169.0';model='UNKNOWN';sandbox='workspace-write';windows_sandbox='unelevated';user_config='ignored';phase='canonical';discovery='explicit source loading'} | ConvertTo-Json | Set-Content -LiteralPath "$result-receipt.json" -Encoding utf8NoBOM
    Write-Output "$case completed with CLI exit $code; behavioral verdict still requires actions/content review"
}

